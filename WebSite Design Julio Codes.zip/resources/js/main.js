// document.getElementById("myBtn").addEventListener("click", function(){
//     document.getElementById("navlist").classList.add('active');
// });

// document.getElementById("myBtn2").addEventListener("click", function(){
//     document.getElementById("navlist").classList.remove('active');
// });


function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
      x.className += " responsive";
    } else {
      x.className = "topnav";
    }
  }